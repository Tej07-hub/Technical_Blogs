# ***"ARTIFICIAL INTELLIGENCE AND GENERATIVE AI MAY BE THE MOST IMPORTANT TECHNOLOGY FOR NEW GENERATION'S"***

![](./image1.jpeg){width="6.268055555555556in"
height="3.0409722222222224in"}

*What is Generative AI ?*

Genertaive AI Is A Generative Artificial Intelligence It Is A Form Of
AI, Which Is Use To Create New Contents.

## *Do you Know How AI Works ?*

Don't worry I let you know . So ,It uses machine learning algorithms
like generative Adversarial Network(GANs) and Transformer models , it
learn patterns in data and create similar contents.

## *Why it is important for new generations*

***AI*** is a next level invention.Today it is not far developed but in
future it will be more helpful for upcoming generations

***LLMs*** Language is used for more than human communication. Code is
the language of computers. Protein and molecular sequences are the
language of biology. Large language models can be applied to such
languages or scenarios in which communication of different types is
needed. These models broaden AI's reach across industries and
enterprises, and are expected to enable a new wave of research,
creativity and productivity, as they can help to generate complex
solutions for the world's toughest problems.

*Drawback of AI*

 AI is certainly a game-changer, but it does come with its own set of drawbacks:

1.  **High Cost**: AI Is Expensive Because , AI Is New In Market But In
    Future It Will Be Affordable For Everyone

2.  **Job underAi**: Automation could lead to job losses in certain sectors, sparking concerns over employment.

3.  **Privacy Issues**: The use of vast amounts of data raises significant privacy and security concerns.

4.  **Lack of Human Touch**: AI lacks empathy and genuine understanding, which can be critical in areas like mental health.

*What Is Impact of AI in Various Industries...*

**1. Manufacturing**

![](./image2.jpeg){width="3.396583552055993in"
height="1.6060608048993876in"}

In New Era New Generation Use AI Force To Get More Accurate Output Also
To Reduce The Cost Of Human And To Enhance Decision Making AI Is An
Automation Process Because Of This It Is Cost Effective For The
Businesses.

**2.Artificial intelligance Farming**

![](./image3.jpeg){width="2.0537193788276467in"
height="1.3863626421697288in"}

As We Know Farmers Do Farming By Traditional Ways But In This New Era Of
Innovation Farmers Are Willing To Use Ai For Farming , Because It Save
Times Of Farmers. There Are So Many Equipment's Which Are Use In Farming
Currently Like, Drone Sprayer, Ai Based Cultivation Machines , AI Soil
Tester Etc.

**3.Virtual Assistance**

Many Companies Prefer Virtual Assistance To Save Time And Money .Virtual
Assistance Is A Software Which Is Use For Solving Problems Also We Can
Say Solving Doubts . Many Companies Have Their Own Virtual Assitances.
For Example Siri, Chatgpt , Gamma ai Etc.

I hope you like my blog I write Whatever I know.
